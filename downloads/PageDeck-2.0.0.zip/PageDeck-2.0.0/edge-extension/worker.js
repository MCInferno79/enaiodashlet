// src/shared/config.ts
var keyRE = /^[a-zA-Z0-9_-]{1,64}$/;
var isKey = (s) => typeof s === "string" && keyRE.test(s);
function plain(v) {
  return !!v && typeof v === "object" && !Array.isArray(v);
}
function short(v, n) {
  return typeof v === "string" && v.length <= n && !/[\u0000-\u001f]/.test(v);
}
function parsePattern(pattern) {
  if (!short(pattern, 1024) || !pattern.trim() || pattern !== pattern.trim()) throw new Error("Ung\xFCltiges Domain-/Pfadmuster.");
  const bare = pattern.replace(/^https?:\/\//i, "");
  if (/[?#@\\\s:]/.test(bare)) throw new Error("Muster nur als Hostname und optional /Pfad angeben; keine Parameter, Ports oder Zugangsdaten.");
  const [rawHost = "", ...rest] = bare.split("/");
  const wildcard = rawHost.startsWith("*.");
  const ascii = new URL("https://" + (wildcard ? rawHost.slice(2) : rawHost)).hostname.toLowerCase().replace(/\.$/, "");
  if (ascii.length > 253 || !ascii.split(".").every((x) => /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(x))) throw new Error("Ung\xFCltiger Hostname.");
  const path = rest.length ? "/" + rest.join("/") : "";
  if (path.includes("*") || /%(?:2f|5c)/i.test(path) || path.split("/").some((x) => x === "." || x === "..")) throw new Error("Pfad ohne Wildcards oder Punktsegmente angeben.");
  return { host: ascii, wildcard, path: path === "/" ? "" : path.replace(/\/$/, "") };
}
function validateConfig(v) {
  if (!plain(v) || Object.keys(v).some((k) => !["version", "paused", "unknown", "defaultProfile", "deviceIds", "rules"].includes(k))) throw new Error("Ung\xFCltige Konfiguration.");
  if (v.version !== 1 || typeof v.paused !== "boolean" || !["release", "keep", "default"].includes(String(v.unknown)) || !short(v.defaultProfile, 64) || v.defaultProfile && !isKey(v.defaultProfile)) throw new Error("Ung\xFCltige Grundeinstellungen.");
  if (v.unknown === "default" && !v.defaultProfile) throw new Error("Standardprofil ausw\xE4hlen.");
  if (!Array.isArray(v.deviceIds) || v.deviceIds.length > 32 || !v.deviceIds.every((x) => short(x, 128) && x.length > 0)) throw new Error("Ung\xFCltige Ger\xE4teauswahl.");
  if (!Array.isArray(v.rules) || v.rules.length > 200) throw new Error("H\xF6chstens 200 Regeln zul\xE4ssig.");
  const ids = /* @__PURE__ */ new Set();
  const rules = v.rules.map((r) => {
    if (!plain(r) || Object.keys(r).some((k) => !["id", "name", "pattern", "profile", "priority", "enabled"].includes(k)) || !isKey(r.id) || ids.has(r.id) || !short(r.name, 100) || !r.name || !short(r.pattern, 1024) || !isKey(r.profile) || !Number.isInteger(r.priority) || Math.abs(Number(r.priority)) > 1e4 || typeof r.enabled !== "boolean") throw new Error("Ung\xFCltige oder doppelte Regel.");
    ids.add(r.id);
    parsePattern(r.pattern);
    return { id: r.id, name: r.name, pattern: r.pattern, profile: r.profile, priority: r.priority, enabled: r.enabled };
  });
  return { version: 1, paused: v.paused, unknown: v.unknown, defaultProfile: v.defaultProfile, deviceIds: [...v.deviceIds], rules };
}
function matchRule(rawUrl, rules) {
  let url;
  try {
    url = new URL(rawUrl);
  } catch {
    return { host: "" };
  }
  if (!["http:", "https:"].includes(url.protocol)) return { host: "" };
  const host = url.hostname.toLowerCase().replace(/\.$/, "");
  const matched = rules.filter((r) => {
    if (!r.enabled) return false;
    const p = parsePattern(r.pattern);
    const hostOK = p.wildcard ? host.endsWith("." + p.host) && host !== p.host : host === p.host;
    return hostOK && (!p.path || url.pathname === p.path || url.pathname.startsWith(p.path + "/"));
  });
  matched.sort((a, b) => b.priority - a.priority);
  return { host, rule: matched[0] };
}
var DEFAULT_CONFIG = {
  version: 1,
  paused: false,
  unknown: "release",
  defaultProfile: "",
  deviceIds: [],
  rules: []
};

// src/shared/workspaces.ts
var EMPTY_WORKSPACES = { version: 1, websites: [] };
var object = (v) => !!v && typeof v === "object" && !Array.isArray(v);
var text = (v, max) => typeof v === "string" && v.length <= max && !/[\u0000-\u0008\u000b-\u001f]/.test(v);
function validateWorkspaces(value) {
  if (!object(value) || Object.keys(value).some((k) => !["version", "websites"].includes(k)) || value.version !== 1 || !Array.isArray(value.websites) || value.websites.length > 100) throw new Error("Ung\xFCltige Webseiten-Konfiguration (maximal 100 Webseiten).");
  const ids = /* @__PURE__ */ new Set();
  const websites = value.websites.map((site) => {
    if (!object(site) || Object.keys(site).some((k) => !["id", "name", "pattern", "priority", "enabled", "buttons"].includes(k)) || !isKey(site.id) || ids.has(site.id) || !text(site.name, 100) || !site.name.trim() || !text(site.pattern, 1024) || typeof site.enabled !== "boolean" || !Number.isInteger(site.priority) || Math.abs(Number(site.priority)) > 1e4 || !Array.isArray(site.buttons) || site.buttons.length > 32) throw new Error("Webseite, Muster oder Tastenbelegung ung\xFCltig.");
    ids.add(site.id);
    parsePattern(site.pattern);
    const slots = /* @__PURE__ */ new Set();
    const buttons = site.buttons.map((button) => {
      if (!object(button) || Object.keys(button).some((k) => !["slot", "label", "steps"].includes(k)) || !Number.isInteger(button.slot) || Number(button.slot) < 1 || Number(button.slot) > 32 || slots.has(Number(button.slot)) || !text(button.label, 50) || !button.label.trim() || /[\r\n\t]/.test(button.label) || !Array.isArray(button.steps) || button.steps.length < 1 || button.steps.length > 10) throw new Error("Je Webseite sind bis zu 32 eindeutige Tasten mit je 1\u201310 Schritten m\xF6glich.");
      slots.add(Number(button.slot));
      const rawSteps = button.steps;
      const steps = rawSteps.map((step, index) => {
        if (!object(step) || Object.keys(step).some((k) => !["type", "target", "value"].includes(k)) || !["click", "fill", "text", "hotkey", "scroll", "open"].includes(String(step.type)) || !text(step.target, 1e3) || !text(step.value, 1e4)) throw new Error("Aktionsschritt ung\xFCltig.");
        if (["click", "fill"].includes(String(step.type)) && !step.target.trim()) throw new Error("F\xFCr Klicken und Feld ausf\xFCllen ist ein CSS-Selektor erforderlich.");
        if (step.type === "open") {
          const url = new URL(step.value);
          if (!["http:", "https:"].includes(url.protocol) || url.username || url.password || index !== rawSteps.length - 1) throw new Error("Seite \xF6ffnen ben\xF6tigt eine HTTP(S)-Adresse ohne Zugangsdaten und muss der letzte Schritt sein.");
        }
        if (step.type === "hotkey" && !/^(?:(?:Control|Alt|Shift|Meta)\+){0,4}(?:[a-zA-Z0-9]|Enter|Escape|Tab|Space|ArrowUp|ArrowDown|ArrowLeft|ArrowRight|Delete|Backspace|F(?:[1-9]|1[0-2]))$/.test(step.value)) throw new Error("Seiten-Tastenk\xFCrzel zum Beispiel Control+Shift+k oder Enter angeben.");
        if (step.type === "scroll" && (!/^-?\d{1,5}$/.test(step.value) || Math.abs(Number(step.value)) > 1e4)) throw new Error("Scroll-Abstand zwischen -10000 und 10000 Pixeln angeben.");
        return { type: step.type, target: step.target, value: step.value };
      });
      return { slot: Number(button.slot), label: button.label.trim(), steps };
    });
    return { id: site.id, name: site.name.trim(), pattern: site.pattern, priority: Number(site.priority), enabled: site.enabled, buttons };
  });
  if (JSON.stringify(websites).length > 5e5) throw new Error("Webseiten-Konfiguration ist zu gro\xDF.");
  return { version: 1, websites };
}
function websiteFor(url, config) {
  const id = matchRule(url, config.websites.map((s) => ({ id: s.id, name: s.name, pattern: s.pattern, priority: s.priority, enabled: s.enabled, profile: s.id }))).rule?.id;
  return config.websites.find((s) => s.id === id);
}
function originsFor(pattern) {
  const p = parsePattern(pattern), host = (p.wildcard ? "*." : "") + p.host;
  return ["http://" + host + "/*", "https://" + host + "/*"];
}

// src/extension/page-actions.ts
async function runPageSteps(steps, expectedUrl, expires) {
  try {
    for (const step of steps) {
      if (!Number.isFinite(expires) || Date.now() > expires) return { ok: false, error: "REQUEST_EXPIRED" };
      if (location.href !== expectedUrl || !document.hasFocus()) return { ok: false, error: "CONTEXT_CHANGED" };
      const element = step.target ? document.querySelector(step.target) : document.activeElement;
      if (["click", "fill", "text", "hotkey"].includes(step.type) && !(element instanceof HTMLElement)) return { ok: false, error: "ELEMENT_NOT_FOUND" };
      if (element instanceof HTMLElement && ["click", "fill", "text"].includes(step.type)) {
        const rect = element.getBoundingClientRect(), style = getComputedStyle(element);
        if (!rect.width || !rect.height || style.display === "none" || style.visibility === "hidden" || "disabled" in element && element.disabled) return { ok: false, error: "ELEMENT_UNAVAILABLE" };
      }
      if (step.type === "click") element.click();
      else if (step.type === "fill" || step.type === "text") {
        if (!(element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement) || element.readOnly || element instanceof HTMLInputElement && ["password", "file", "hidden", "checkbox", "radio", "button", "submit"].includes(element.type)) return { ok: false, error: "FIELD_UNSUPPORTED" };
        element.focus();
        let value = step.value;
        if (step.type === "text") {
          const start = element.selectionStart ?? element.value.length, end = element.selectionEnd ?? start;
          value = element.value.slice(0, start) + value + element.value.slice(end);
        }
        const proto = element instanceof HTMLInputElement ? HTMLInputElement.prototype : HTMLTextAreaElement.prototype;
        const previous = element.value, setter = Object.getOwnPropertyDescriptor(proto, "value").set;
        setter.call(element, value);
        if (element.value !== value) {
          setter.call(element, previous);
          return { ok: false, error: "FIELD_VALUE_REJECTED" };
        }
        element.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: step.value }));
        element.dispatchEvent(new Event("change", { bubbles: true }));
      } else if (step.type === "hotkey") {
        const parts = step.value.split("+"), raw = parts.pop(), key = raw === "Space" ? " " : raw;
        const event = { key, code: /^[a-z]$/i.test(raw) ? "Key" + raw.toUpperCase() : raw, ctrlKey: parts.includes("Control"), altKey: parts.includes("Alt"), shiftKey: parts.includes("Shift"), metaKey: parts.includes("Meta"), bubbles: true, cancelable: true };
        element.focus();
        element?.dispatchEvent(new KeyboardEvent("keydown", event));
        element?.dispatchEvent(new KeyboardEvent("keyup", event));
      } else if (step.type === "scroll") window.scrollBy({ top: Number(step.value), behavior: "instant" });
    }
    return { ok: true };
  } catch {
    return { ok: false, error: "PAGE_ACTION_FAILED" };
  }
}

// src/extension/deck-link.ts
function createDeckLink(activeTab2) {
  let socket, token = "", ready = false, paused = false;
  let binding;
  let queue = Promise.resolve();
  const status = async (message, ok = false) => {
    await chrome.storage.session.set({ webStatus: { message, connected: ok, updatedAt: Date.now() } });
  };
  const send = (value) => {
    if (socket?.readyState === WebSocket.OPEN) socket.send(JSON.stringify(value));
  };
  async function layout() {
    if (!ready) return;
    const config = await chrome.storage.local.get(["workspaces", "config"]);
    const sites = validateWorkspaces(config.workspaces ?? EMPTY_WORKSPACES), active = await activeTab2();
    const site = active.focused && !paused && config.config?.paused !== true ? websiteFor(active.url, sites) : void 0;
    if (site && active.tabId !== void 0) {
      const fingerprint = JSON.stringify(site);
      if (!binding || binding.url !== active.url || binding.tabId !== active.tabId || binding.fingerprint !== fingerprint) binding = { context: crypto.randomUUID(), tabId: active.tabId, url: active.url, site, fingerprint };
      send({ type: "layout", context: binding.context, buttons: site.buttons.map((b) => ({ slot: b.slot, label: b.label })) });
      await status(`PageDeck bereit: ${site.name} \xB7 ${site.buttons.length} Taste(n).`, true);
    } else {
      binding = void 0;
      send({ type: "layout", context: crypto.randomUUID(), buttons: [] });
      await status(paused || config.config?.paused === true ? "PageDeck pausiert." : "Verbunden. Aktive Webseite hat keine Tastenbelegung.", true);
    }
  }
  async function execute(p) {
    if (!binding || p.context !== binding.context || !Number.isInteger(p.slot) || typeof p.requestId !== "string" || !/^[a-f0-9]{32}$/.test(p.requestId)) return;
    const current = binding, source = socket;
    if (!Number.isFinite(p.expires) || p.expires < Date.now() || p.expires > Date.now() + 6e3) {
      send({ type: "result", requestId: p.requestId, ok: false });
      await status("Tastenanfrage abgelaufen. Bei Bedarf erneut dr\xFCcken.", ready);
      return;
    }
    let ok = false, error = "CONTEXT_CHANGED";
    try {
      const data = await chrome.storage.local.get(["workspaces", "config"]);
      const active = await activeTab2(), site = websiteFor(active.url, validateWorkspaces(data.workspaces ?? EMPTY_WORKSPACES));
      if (!paused && data.config?.paused !== true && active.focused && active.tabId === current.tabId && active.url === current.url && site && JSON.stringify(site) === current.fingerprint) {
        const button = site.buttons.find((b) => b.slot === p.slot);
        if (button) {
          const dom = button.steps.filter((s) => s.type !== "open");
          if (dom.length && !await chrome.permissions.contains({ origins: originsFor(site.pattern) })) error = "PERMISSION_REQUIRED";
          else {
            ok = true;
            if (dom.length) {
              const result = await chrome.scripting.executeScript({ target: { tabId: current.tabId, frameIds: [0] }, func: runPageSteps, args: [dom, current.url, p.expires] });
              ok = result[0]?.result?.ok === true;
              error = result[0]?.result?.error ?? "PAGE_ACTION_FAILED";
            }
            if (ok && button.steps.at(-1)?.type === "open") {
              const latest = await activeTab2();
              if (Date.now() > p.expires || !latest.focused || latest.tabId !== current.tabId || latest.url !== current.url) {
                ok = false;
                error = "CONTEXT_CHANGED";
              } else await chrome.tabs.update(current.tabId, { url: button.steps.at(-1).value });
            }
          }
        }
      }
    } catch {
      ok = false;
      error = "PAGE_ACTION_FAILED";
    }
    if (socket === source && ready) send({ type: "result", requestId: p.requestId, ok });
    await status(ok ? "Aktion ausgef\xFChrt." : error === "REQUEST_EXPIRED" ? "Tastenanfrage abgelaufen. Bei Bedarf erneut dr\xFCcken." : error === "PERMISSION_REQUIRED" ? "Website-Zugriff fehlt. In den PageDeck-Einstellungen \u201EWebsite freigeben\u201C w\xE4hlen." : error === "ELEMENT_NOT_FOUND" ? "Element nicht gefunden. Selektor und aktive Seite pr\xFCfen." : error === "FIELD_UNSUPPORTED" ? "Dieses Feld unterst\xFCtzt die gew\xE4hlte Texteingabe nicht." : error === "CONTEXT_CHANGED" ? "Aktion verworfen: aktive Webseite oder Tastenbelegung hat sich ge\xE4ndert." : "Seitenaktion konnte nicht ausgef\xFChrt werden. Element, Freigabe und Seitentyp pr\xFCfen.", ready);
  }
  return {
    async sync(nextToken) {
      if (typeof WebSocket === "undefined") return;
      if (!nextToken) {
        socket?.close();
        socket = void 0;
        token = "";
        ready = false;
        binding = void 0;
        return;
      }
      if (socket && token === nextToken && socket.readyState < 2) {
        if (ready) await layout();
        return;
      }
      socket?.close();
      token = nextToken;
      ready = false;
      binding = void 0;
      const current = new WebSocket("ws://127.0.0.1:29381/v1/deck");
      socket = current;
      current.onopen = () => {
        if (socket === current) send({ type: "auth", token });
      };
      current.onmessage = (event) => {
        if (socket !== current) return;
        let p;
        try {
          p = JSON.parse(event.data);
        } catch {
          return;
        }
        if (p?.type === "ready" || p?.type === "ping") {
          ready = true;
          paused = p.paused === true;
          send({ type: "alive" });
          void layout().catch(() => status("Webseiten-Konfiguration konnte nicht gelesen werden."));
        } else if (p?.type === "execute" && ready) {
          queue = queue.then(() => execute(p)).catch(() => {
          });
        }
      };
      current.onclose = () => {
        if (socket === current) {
          ready = false;
          binding = void 0;
          void status("Tastenverbindung getrennt. Stream Deck starten oder Verbindung testen.");
        }
      };
      current.onerror = () => {
        if (socket === current) void status("Tastenverbindung nicht erreichbar. Kopplung und Stream Deck pr\xFCfen.");
      };
    }
  };
}

// src/extension/worker.ts
var BASE = "http://127.0.0.1:29381";
var pending = false;
var running = false;
var revision = 0;
async function api(route, data, token) {
  const response = await fetch(BASE + route, { method: "POST", headers: { "Content-Type": "application/json", ...token ? { Authorization: `Bearer ${token}` } : {} }, body: JSON.stringify(data), cache: "no-store", credentials: "omit", redirect: "error", signal: AbortSignal.timeout(2500) });
  const body = await response.json();
  if (!response.ok) throw new Error(response.status === 401 || response.status === 403 ? "Kopplung fehlt oder wurde erneuert. Bitte erneut koppeln." : response.status === 429 ? "Zu viele Kopplungsversuche. Eine Minute warten." : response.status === 409 ? "Verbindung wurde neu gestartet. Erneuter Versuch folgt." : "Lokaler Dienst: Anfrage abgelehnt.");
  return body;
}
async function settings() {
  const v = await chrome.storage.local.get(["config", "auth"]);
  const candidate = v.auth;
  return { config: validateConfig(v.config ?? DEFAULT_CONFIG), auth: candidate && /^[a-f0-9]{64}$/.test(candidate.token) ? candidate : void 0 };
}
async function saveStatus(s) {
  await chrome.storage.session.set({ status: { ...s, updatedAt: Date.now() } });
}
async function activeTab() {
  const windows = await chrome.windows.getAll({ windowTypes: ["normal", "popup"] });
  const window2 = windows.find((w) => w.focused);
  if (!window2 || window2.id === void 0) return { focused: false, url: "" };
  const [tab] = await chrome.tabs.query({ active: true, windowId: window2.id });
  return { focused: !!tab, url: tab?.url ?? "", tabId: tab?.id };
}
var deckLink = createDeckLink(activeTab);
async function evaluate() {
  const mine = revision;
  const { config, auth } = await settings();
  const active = await activeTab();
  await deckLink.sync(auth?.token);
  const match = matchRule(active.url, config.rules);
  if (!auth?.token) {
    await saveStatus({ connected: false, host: match.host, message: "Bitte zuerst mit dem Stream-Deck-Plugin koppeln." });
    return;
  }
  try {
    const server = await api("/v1/status", {}, auth.token);
    if (mine !== revision) {
      pending = true;
      return;
    }
    const n = await chrome.storage.local.get("sequence");
    const sequence = typeof n.sequence === "number" && Number.isSafeInteger(n.sequence) ? n.sequence + 1 : 1;
    await chrome.storage.local.set({ sequence });
    const latest = await activeTab();
    if (mine !== revision || latest.focused !== active.focused || latest.url !== active.url) {
      pending = true;
      return;
    }
    const legacy = await chrome.storage.local.get("profileSwitchingEnabled");
    const profileSwitching = legacy.profileSwitchingEnabled === true;
    const target = !profileSwitching ? null : match.rule?.profile ?? (config.unknown === "default" ? config.defaultProfile : null);
    const result = await api("/v1/event", { instance: server.instance, sequence, focused: active.focused && profileSwitching, target, keep: !match.rule && config.unknown === "keep", paused: config.paused, deviceIds: config.deviceIds }, auth.token);
    const missing = result.results.some((r) => r.state === "profile-missing");
    const failed = result.results.some((r) => r.state === "sdk-error");
    const paused = config.paused || result.paused;
    const selected = result.devices.filter((d) => d.isConnected && (!config.deviceIds.length || config.deviceIds.includes(d.id)));
    const requested = result.results.some((r) => r.state === "command-sent");
    let message = !profileSwitching ? "PageDeck-Webseitenmodus aktiv. Eigene Tastenaktionen werden \xFCber die Webseiten-Einstellungen verwaltet." : paused ? "Automatik pausiert \u2013 Profilfreigabe angefordert." : !active.focused ? "Edge im Hintergrund \u2013 Profilfreigabe angefordert." : selected.length === 0 ? "Kein ausgew\xE4hltes Stream Deck verbunden." : failed ? "Stream-Deck-Befehl fehlgeschlagen." : missing ? "Profil f\xFCr dieses Ger\xE4t fehlt. Exportdatei mit Profile-Paket-erstellen.html lokal einbinden und das erzeugte Plugin installieren." : requested ? `Microsoft Edge erkannt \u2013 ${match.host || "interne Seite"} \u2013 Profilbefehl ${target ?? "beibehalten"} gesendet.` : "Keine passende Regel \u2013 Profilfreigabe angefordert.";
    await saveStatus({ connected: true, host: match.host, profile: target, message, server: result });
    await chrome.action.setBadgeText({ text: paused ? "\u2161" : missing || failed ? "!" : "" });
    await chrome.action.setBadgeBackgroundColor({ color: missing || failed ? "#b45309" : "#0f766e" });
  } catch (e) {
    await saveStatus({ connected: false, host: match.host, message: e instanceof TypeError || e instanceof Error && e.name === "TimeoutError" ? "Lokaler Dienst nicht erreichbar. Stream Deck starten; erneuter Versuch beim n\xE4chsten Browserereignis oder innerhalb von etwa 30 Sekunden." : e instanceof Error ? e.message : "Verbindungsfehler." });
    await chrome.action.setBadgeText({ text: "!" });
  }
}
async function drain() {
  if (running) return;
  running = true;
  try {
    while (pending) {
      pending = false;
      await evaluate();
    }
  } catch {
    await saveStatus({ connected: false, message: "Einstellungen oder Browserzustand konnten nicht gelesen werden." });
  } finally {
    running = false;
  }
}
function schedule() {
  ++revision;
  pending = true;
  void drain();
}
chrome.tabs.onActivated.addListener(schedule);
chrome.tabs.onUpdated.addListener((_id, change, tab) => {
  if (tab.active && (change.url !== void 0 || change.status === "complete")) schedule();
});
chrome.tabs.onCreated.addListener(schedule);
chrome.tabs.onRemoved.addListener(schedule);
chrome.tabs.onReplaced.addListener(schedule);
chrome.tabs.onAttached.addListener(schedule);
chrome.tabs.onDetached.addListener(schedule);
chrome.windows.onFocusChanged.addListener(schedule);
chrome.windows.onRemoved.addListener(schedule);
chrome.webNavigation.onHistoryStateUpdated.addListener((e) => {
  if (e.frameId === 0) schedule();
});
chrome.webNavigation.onReferenceFragmentUpdated.addListener((e) => {
  if (e.frameId === 0) schedule();
});
chrome.runtime.onStartup.addListener(schedule);
chrome.runtime.onInstalled.addListener(() => {
  void chrome.storage.local.get("config").then((v) => {
    if (!v.config) return chrome.storage.local.set({ config: DEFAULT_CONFIG });
  }).then(schedule);
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && (changes.config || changes.auth || changes.workspaces || changes.profileSwitchingEnabled)) schedule();
});
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === "heki-reconnect") schedule();
});
chrome.action.onClicked.addListener(() => {
  void chrome.runtime.openOptionsPage();
});
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (sender.id !== chrome.runtime.id || !["options.html", "workspaces.html"].some((p) => sender.url === chrome.runtime.getURL(p))) return;
  const run = async () => {
    switch (message?.type) {
      case "profiles:enable": {
        if (typeof message.enabled !== "boolean") throw new Error("Ung\xFCltige Einstellung.");
        await chrome.storage.local.set({ profileSwitchingEnabled: message.enabled });
        schedule();
        return { ok: true };
      }
      case "workspaces:get": {
        const data = await chrome.storage.local.get("workspaces");
        const s = await chrome.storage.session.get("webStatus");
        return { ok: true, config: validateWorkspaces(data.workspaces ?? EMPTY_WORKSPACES), status: s.webStatus };
      }
      case "workspaces:save": {
        const config = validateWorkspaces(message.config);
        await chrome.storage.local.set({ workspaces: config });
        schedule();
        return { ok: true };
      }
      case "status": {
        const v = await chrome.storage.session.get("status");
        return { ok: true, status: v.status };
      }
      case "refresh":
        schedule();
        return { ok: true };
      case "save": {
        const config = validateConfig(message.config);
        await chrome.storage.local.set({ config });
        schedule();
        return { ok: true };
      }
      case "pair": {
        if (typeof message.code !== "string" || !/^[a-f0-9]{48}$/.test(message.code)) throw new Error("Kopplungscode ung\xFCltig oder unvollst\xE4ndig.");
        const auth = await api("/v1/pair", { code: message.code });
        await chrome.storage.local.set({ auth: { token: auth.token } });
        schedule();
        return { ok: true };
      }
      case "resume-plugin": {
        const { auth } = await settings();
        if (!auth) throw new Error("Bitte koppeln.");
        await api("/v1/pause", { paused: false }, auth.token);
        schedule();
        return { ok: true };
      }
      default:
        throw new Error("Unbekannter Befehl.");
    }
  };
  void run().then(respond, (e) => respond({ ok: false, error: e instanceof Error ? e.message : "Fehler" }));
  return true;
});
void chrome.alarms.create("heki-reconnect", { periodInMinutes: 0.5 });
schedule();
