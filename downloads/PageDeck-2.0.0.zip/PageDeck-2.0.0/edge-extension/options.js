// src/shared/config.ts
var keyRE = /^[a-zA-Z0-9_-]{1,64}$/;
var isKey = (s) => typeof s === "string" && keyRE.test(s);
function plain(v) {
  return !!v && typeof v === "object" && !Array.isArray(v);
}
function short(v, n) {
  return typeof v === "string" && v.length <= n && !/[\u0000-\u001f]/.test(v);
}
function parsePattern(pattern) {
  if (!short(pattern, 1024) || !pattern.trim() || pattern !== pattern.trim()) throw new Error("Ung\xFCltiges Domain-/Pfadmuster.");
  const bare = pattern.replace(/^https?:\/\//i, "");
  if (/[?#@\\\s:]/.test(bare)) throw new Error("Muster nur als Hostname und optional /Pfad angeben; keine Parameter, Ports oder Zugangsdaten.");
  const [rawHost = "", ...rest] = bare.split("/");
  const wildcard = rawHost.startsWith("*.");
  const ascii = new URL("https://" + (wildcard ? rawHost.slice(2) : rawHost)).hostname.toLowerCase().replace(/\.$/, "");
  if (ascii.length > 253 || !ascii.split(".").every((x) => /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(x))) throw new Error("Ung\xFCltiger Hostname.");
  const path = rest.length ? "/" + rest.join("/") : "";
  if (path.includes("*") || /%(?:2f|5c)/i.test(path) || path.split("/").some((x) => x === "." || x === "..")) throw new Error("Pfad ohne Wildcards oder Punktsegmente angeben.");
  return { host: ascii, wildcard, path: path === "/" ? "" : path.replace(/\/$/, "") };
}
function validateConfig(v) {
  if (!plain(v) || Object.keys(v).some((k) => !["version", "paused", "unknown", "defaultProfile", "deviceIds", "rules"].includes(k))) throw new Error("Ung\xFCltige Konfiguration.");
  if (v.version !== 1 || typeof v.paused !== "boolean" || !["release", "keep", "default"].includes(String(v.unknown)) || !short(v.defaultProfile, 64) || v.defaultProfile && !isKey(v.defaultProfile)) throw new Error("Ung\xFCltige Grundeinstellungen.");
  if (v.unknown === "default" && !v.defaultProfile) throw new Error("Standardprofil ausw\xE4hlen.");
  if (!Array.isArray(v.deviceIds) || v.deviceIds.length > 32 || !v.deviceIds.every((x) => short(x, 128) && x.length > 0)) throw new Error("Ung\xFCltige Ger\xE4teauswahl.");
  if (!Array.isArray(v.rules) || v.rules.length > 200) throw new Error("H\xF6chstens 200 Regeln zul\xE4ssig.");
  const ids = /* @__PURE__ */ new Set();
  const rules = v.rules.map((r) => {
    if (!plain(r) || Object.keys(r).some((k) => !["id", "name", "pattern", "profile", "priority", "enabled"].includes(k)) || !isKey(r.id) || ids.has(r.id) || !short(r.name, 100) || !r.name || !short(r.pattern, 1024) || !isKey(r.profile) || !Number.isInteger(r.priority) || Math.abs(Number(r.priority)) > 1e4 || typeof r.enabled !== "boolean") throw new Error("Ung\xFCltige oder doppelte Regel.");
    ids.add(r.id);
    parsePattern(r.pattern);
    return { id: r.id, name: r.name, pattern: r.pattern, profile: r.profile, priority: r.priority, enabled: r.enabled };
  });
  return { version: 1, paused: v.paused, unknown: v.unknown, defaultProfile: v.defaultProfile, deviceIds: [...v.deviceIds], rules };
}
var DEFAULT_CONFIG = {
  version: 1,
  paused: false,
  unknown: "release",
  defaultProfile: "",
  deviceIds: [],
  rules: []
};

// src/extension/options.ts
var el = (id) => document.getElementById(id);
var config;
var catalog = [];
var serverDevices = [];
var feedback = (s) => {
  el("feedback").textContent = s;
};
async function message(data) {
  const r = await chrome.runtime.sendMessage(data);
  if (!r?.ok) throw new Error(r?.error ?? "Service Worker nicht erreichbar.");
  return r;
}
function option(value, text) {
  const o = document.createElement("option");
  o.value = value;
  o.textContent = text;
  return o;
}
function fillProfiles(select, value, optional = false) {
  select.replaceChildren();
  if (optional) select.append(option("", "Bitte ausw\xE4hlen"));
  const keys = new Set(catalog.map((p) => p.key));
  if (value) keys.add(value);
  if (!keys.size) select.append(option("", "Noch keine Profile eingebunden"));
  for (const key of keys) {
    const p = catalog.find((p2) => p2.key === key);
    select.append(option(key, p ? `${p.label} [${key}]` : `${key} \u2013 noch nicht eingebunden`));
  }
  select.value = value;
}
function input(value, type = "text") {
  const i = document.createElement("input");
  i.type = type;
  i.value = value;
  return i;
}
function drawRules() {
  const tbody = el("rules");
  tbody.replaceChildren();
  config.rules.forEach((rule, index) => {
    const tr = document.createElement("tr");
    tr.dataset.id = rule.id;
    const enabled = input("", "checkbox");
    enabled.checked = rule.enabled;
    enabled.setAttribute("aria-label", `Regel ${index + 1} aktiviert`);
    const name = input(rule.name);
    name.maxLength = 100;
    name.required = true;
    name.setAttribute("aria-label", "Anzeigename");
    const pattern = input(rule.pattern);
    pattern.required = true;
    pattern.maxLength = 1024;
    pattern.setAttribute("aria-label", "Domain oder Pfadmuster");
    const profile = document.createElement("select");
    fillProfiles(profile, rule.profile);
    profile.setAttribute("aria-label", "Plugin-Profil");
    const priority = input(String(rule.priority), "number");
    priority.min = "-10000";
    priority.max = "10000";
    priority.required = true;
    priority.setAttribute("aria-label", "Priorit\xE4t");
    const remove = document.createElement("button");
    remove.type = "button";
    remove.textContent = "L\xF6schen";
    remove.addEventListener("click", () => {
      config = collect();
      config.rules.splice(index, 1);
      drawRules();
    });
    for (const child of [enabled, name, pattern, profile, priority, remove]) {
      const td = document.createElement("td");
      td.append(child);
      tr.append(td);
    }
    tbody.append(tr);
  });
  el("missing").textContent = "Die Profilauswahl enth\xE4lt ausschlie\xDFlich eingebundene Exportprofile. Weitere Profile mit Profile-Paket-erstellen.html lokal erg\xE4nzen und das erzeugte Installationspaket \xF6ffnen.";
}
function drawDevices() {
  const select = el("device-select");
  select.replaceChildren(option("*", "Alle passenden Ger\xE4te"));
  const ids = /* @__PURE__ */ new Set([...serverDevices.map((d) => d.id), ...config.deviceIds]);
  for (const id of ids) {
    const d = serverDevices.find((d2) => d2.id === id);
    select.append(option(id, d ? `${d.name} \xB7 Typ ${d.type} \xB7 ${d.size.columns} \xD7 ${d.size.rows}${d.isConnected ? "" : " \xB7 getrennt"}` : `${id} \xB7 derzeit unbekannt`));
  }
  for (const o of select.options) o.selected = config.deviceIds.length === 0 ? o.value === "*" : config.deviceIds.includes(o.value);
}
function draw() {
  drawRules();
  el("unknown").value = config.unknown;
  fillProfiles(el("default-profile"), config.defaultProfile, true);
  el("pause").textContent = config.paused ? "Automatik fortsetzen" : "Automatik pausieren";
  drawDevices();
}
function collect() {
  const rules = [...el("rules").querySelectorAll("tr")].map((tr) => {
    const inputs = tr.querySelectorAll("input");
    return { id: tr.dataset.id, name: inputs[1].value, pattern: inputs[2].value, profile: tr.querySelector("select").value, priority: Number(inputs[3].value), enabled: inputs[0].checked };
  });
  const selected = [...el("device-select").selectedOptions].map((o) => o.value);
  return { ...config, rules, unknown: el("unknown").value, defaultProfile: el("default-profile").value, deviceIds: selected.includes("*") ? [] : selected };
}
async function updateStatus() {
  const { status } = await message({ type: "status" });
  if (!status) return;
  el("status").textContent = status.message;
  el("connection").textContent = status.connected ? "Lokal verbunden" : "Nicht verbunden";
  el("resume-plugin").hidden = !status.server?.paused;
  if (status.server) {
    const changed = JSON.stringify(catalog) !== JSON.stringify(status.server.profiles) || JSON.stringify(serverDevices) !== JSON.stringify(status.server.devices);
    if (changed) {
      config = collect();
      catalog = status.server.profiles;
      serverDevices = status.server.devices;
      draw();
    }
    el("devices").textContent = serverDevices.map((d) => `${d.name}: Typ ${d.type}, ${d.size.columns} \xD7 ${d.size.rows}${d.isConnected ? "" : " (getrennt)"}`).join(" \xB7 ");
  }
}
function action(id, run) {
  el(id).addEventListener("click", () => {
    Promise.resolve().then(run).catch((e) => feedback(e.message));
  });
}
el("form").addEventListener("submit", (e) => {
  e.preventDefault();
  void (async () => {
    config = validateConfig(collect());
    await message({ type: "save", config });
    feedback("Einstellungen gespeichert.");
  })().catch((e2) => feedback(e2.message));
});
action("add", () => {
  config = collect();
  config.rules.push({ id: crypto.randomUUID(), name: "Neue Website", pattern: "example.org", profile: catalog[0]?.key ?? "", priority: 0, enabled: true });
  drawRules();
});
action("test", async () => {
  await message({ type: "refresh" });
  feedback("Verbindungstest angefordert; Status wird automatisch aktualisiert.");
});
action("pause", async () => {
  config = validateConfig({ ...collect(), paused: !config.paused });
  await message({ type: "save", config });
  draw();
  feedback(config.paused ? "Automatik pausiert." : "Automatik fortgesetzt.");
});
action("resume-plugin", async () => {
  await message({ type: "resume-plugin" });
  feedback("Pause am Stream Deck aufgehoben.");
});
action("pair", async () => {
  await message({ type: "pair", code: el("pair-code").value.trim() });
  el("pair-code").value = "";
  feedback("Kopplung erfolgreich.");
});
action("export", () => {
  const clean = validateConfig(collect());
  const url = URL.createObjectURL(new Blob([JSON.stringify(clean, null, 2)], { type: "application/json" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = "pagedeck-regeln.json";
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1e3);
  feedback("Konfiguration exportiert. Kopplungsschl\xFCssel werden nicht exportiert.");
});
el("import").addEventListener("change", (e) => {
  void (async () => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 1024 * 1024) throw new Error("Datei zu gro\xDF.");
    config = validateConfig(JSON.parse(await file.text()));
    draw();
    feedback("Konfiguration gepr\xFCft und geladen. Zum \xDCbernehmen speichern.");
  })().catch((e2) => feedback(e2.message));
});
chrome.storage.onChanged.addListener((_changes, area) => {
  if (area === "session") void updateStatus().catch((e) => feedback(e.message));
});
el("legacy-enabled").onchange = () => {
  void message({ type: "profiles:enable", enabled: el("legacy-enabled").checked }).catch((e) => feedback(e.message));
};
var saved = await chrome.storage.local.get(["config", "profileSwitchingEnabled"]);
el("legacy-enabled").checked = saved.profileSwitchingEnabled === true;
config = validateConfig(saved.config ?? DEFAULT_CONFIG);
draw();
await message({ type: "refresh" });
await updateStatus();
