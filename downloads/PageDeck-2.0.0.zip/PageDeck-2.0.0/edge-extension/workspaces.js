// src/shared/config.ts
var keyRE = /^[a-zA-Z0-9_-]{1,64}$/;
var isKey = (s) => typeof s === "string" && keyRE.test(s);
function plain(v) {
  return !!v && typeof v === "object" && !Array.isArray(v);
}
function short(v, n) {
  return typeof v === "string" && v.length <= n && !/[\u0000-\u001f]/.test(v);
}
function parsePattern(pattern) {
  if (!short(pattern, 1024) || !pattern.trim() || pattern !== pattern.trim()) throw new Error("Ung\xFCltiges Domain-/Pfadmuster.");
  const bare = pattern.replace(/^https?:\/\//i, "");
  if (/[?#@\\\s:]/.test(bare)) throw new Error("Muster nur als Hostname und optional /Pfad angeben; keine Parameter, Ports oder Zugangsdaten.");
  const [rawHost = "", ...rest] = bare.split("/");
  const wildcard = rawHost.startsWith("*.");
  const ascii = new URL("https://" + (wildcard ? rawHost.slice(2) : rawHost)).hostname.toLowerCase().replace(/\.$/, "");
  if (ascii.length > 253 || !ascii.split(".").every((x) => /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(x))) throw new Error("Ung\xFCltiger Hostname.");
  const path = rest.length ? "/" + rest.join("/") : "";
  if (path.includes("*") || /%(?:2f|5c)/i.test(path) || path.split("/").some((x) => x === "." || x === "..")) throw new Error("Pfad ohne Wildcards oder Punktsegmente angeben.");
  return { host: ascii, wildcard, path: path === "/" ? "" : path.replace(/\/$/, "") };
}
function validateConfig(v) {
  if (!plain(v) || Object.keys(v).some((k) => !["version", "paused", "unknown", "defaultProfile", "deviceIds", "rules"].includes(k))) throw new Error("Ung\xFCltige Konfiguration.");
  if (v.version !== 1 || typeof v.paused !== "boolean" || !["release", "keep", "default"].includes(String(v.unknown)) || !short(v.defaultProfile, 64) || v.defaultProfile && !isKey(v.defaultProfile)) throw new Error("Ung\xFCltige Grundeinstellungen.");
  if (v.unknown === "default" && !v.defaultProfile) throw new Error("Standardprofil ausw\xE4hlen.");
  if (!Array.isArray(v.deviceIds) || v.deviceIds.length > 32 || !v.deviceIds.every((x) => short(x, 128) && x.length > 0)) throw new Error("Ung\xFCltige Ger\xE4teauswahl.");
  if (!Array.isArray(v.rules) || v.rules.length > 200) throw new Error("H\xF6chstens 200 Regeln zul\xE4ssig.");
  const ids = /* @__PURE__ */ new Set();
  const rules = v.rules.map((r) => {
    if (!plain(r) || Object.keys(r).some((k) => !["id", "name", "pattern", "profile", "priority", "enabled"].includes(k)) || !isKey(r.id) || ids.has(r.id) || !short(r.name, 100) || !r.name || !short(r.pattern, 1024) || !isKey(r.profile) || !Number.isInteger(r.priority) || Math.abs(Number(r.priority)) > 1e4 || typeof r.enabled !== "boolean") throw new Error("Ung\xFCltige oder doppelte Regel.");
    ids.add(r.id);
    parsePattern(r.pattern);
    return { id: r.id, name: r.name, pattern: r.pattern, profile: r.profile, priority: r.priority, enabled: r.enabled };
  });
  return { version: 1, paused: v.paused, unknown: v.unknown, defaultProfile: v.defaultProfile, deviceIds: [...v.deviceIds], rules };
}
var DEFAULT_CONFIG = {
  version: 1,
  paused: false,
  unknown: "release",
  defaultProfile: "",
  deviceIds: [],
  rules: []
};

// src/shared/workspaces.ts
var EMPTY_WORKSPACES = { version: 1, websites: [] };
var object = (v) => !!v && typeof v === "object" && !Array.isArray(v);
var text = (v, max) => typeof v === "string" && v.length <= max && !/[\u0000-\u0008\u000b-\u001f]/.test(v);
function validateWorkspaces(value) {
  if (!object(value) || Object.keys(value).some((k) => !["version", "websites"].includes(k)) || value.version !== 1 || !Array.isArray(value.websites) || value.websites.length > 100) throw new Error("Ung\xFCltige Webseiten-Konfiguration (maximal 100 Webseiten).");
  const ids = /* @__PURE__ */ new Set();
  const websites = value.websites.map((site2) => {
    if (!object(site2) || Object.keys(site2).some((k) => !["id", "name", "pattern", "priority", "enabled", "buttons"].includes(k)) || !isKey(site2.id) || ids.has(site2.id) || !text(site2.name, 100) || !site2.name.trim() || !text(site2.pattern, 1024) || typeof site2.enabled !== "boolean" || !Number.isInteger(site2.priority) || Math.abs(Number(site2.priority)) > 1e4 || !Array.isArray(site2.buttons) || site2.buttons.length > 32) throw new Error("Webseite, Muster oder Tastenbelegung ung\xFCltig.");
    ids.add(site2.id);
    parsePattern(site2.pattern);
    const slots = /* @__PURE__ */ new Set();
    const buttons = site2.buttons.map((button2) => {
      if (!object(button2) || Object.keys(button2).some((k) => !["slot", "label", "steps"].includes(k)) || !Number.isInteger(button2.slot) || Number(button2.slot) < 1 || Number(button2.slot) > 32 || slots.has(Number(button2.slot)) || !text(button2.label, 50) || !button2.label.trim() || /[\r\n\t]/.test(button2.label) || !Array.isArray(button2.steps) || button2.steps.length < 1 || button2.steps.length > 10) throw new Error("Je Webseite sind bis zu 32 eindeutige Tasten mit je 1\u201310 Schritten m\xF6glich.");
      slots.add(Number(button2.slot));
      const rawSteps = button2.steps;
      const steps = rawSteps.map((step, index) => {
        if (!object(step) || Object.keys(step).some((k) => !["type", "target", "value"].includes(k)) || !["click", "fill", "text", "hotkey", "scroll", "open"].includes(String(step.type)) || !text(step.target, 1e3) || !text(step.value, 1e4)) throw new Error("Aktionsschritt ung\xFCltig.");
        if (["click", "fill"].includes(String(step.type)) && !step.target.trim()) throw new Error("F\xFCr Klicken und Feld ausf\xFCllen ist ein CSS-Selektor erforderlich.");
        if (step.type === "open") {
          const url = new URL(step.value);
          if (!["http:", "https:"].includes(url.protocol) || url.username || url.password || index !== rawSteps.length - 1) throw new Error("Seite \xF6ffnen ben\xF6tigt eine HTTP(S)-Adresse ohne Zugangsdaten und muss der letzte Schritt sein.");
        }
        if (step.type === "hotkey" && !/^(?:(?:Control|Alt|Shift|Meta)\+){0,4}(?:[a-zA-Z0-9]|Enter|Escape|Tab|Space|ArrowUp|ArrowDown|ArrowLeft|ArrowRight|Delete|Backspace|F(?:[1-9]|1[0-2]))$/.test(step.value)) throw new Error("Seiten-Tastenk\xFCrzel zum Beispiel Control+Shift+k oder Enter angeben.");
        if (step.type === "scroll" && (!/^-?\d{1,5}$/.test(step.value) || Math.abs(Number(step.value)) > 1e4)) throw new Error("Scroll-Abstand zwischen -10000 und 10000 Pixeln angeben.");
        return { type: step.type, target: step.target, value: step.value };
      });
      return { slot: Number(button2.slot), label: button2.label.trim(), steps };
    });
    return { id: site2.id, name: site2.name.trim(), pattern: site2.pattern, priority: Number(site2.priority), enabled: site2.enabled, buttons };
  });
  if (JSON.stringify(websites).length > 5e5) throw new Error("Webseiten-Konfiguration ist zu gro\xDF.");
  return { version: 1, websites };
}
function originsFor(pattern) {
  const p = parsePattern(pattern), host = (p.wildcard ? "*." : "") + p.host;
  return ["http://" + host + "/*", "https://" + host + "/*"];
}

// src/extension/workspaces-ui.ts
var el = (id) => document.getElementById(id);
var config = structuredClone(EMPTY_WORKSPACES);
var siteIndex = 0;
var buttonIndex = 0;
var site = () => config.websites[siteIndex];
var button = () => site()?.buttons[buttonIndex];
var feedback = (message2) => {
  el("feedback").textContent = message2;
};
async function message(value) {
  const result = await chrome.runtime.sendMessage(value);
  if (!result?.ok) throw new Error(result?.error ?? "Hintergrunddienst nicht erreichbar.");
  return result;
}
function option(value, label) {
  const o = document.createElement("option");
  o.value = value;
  o.textContent = label;
  return o;
}
function draw() {
  const list = el("site-list");
  list.replaceChildren(...config.websites.map((s2, i) => option(String(i), s2.name)));
  list.value = String(siteIndex);
  el("empty").hidden = !!site();
  el("editor").hidden = !site();
  const s = site();
  if (!s) return;
  el("permission").textContent = "Klicken und Texteingaben ben\xF6tigen Ihre Freigabe f\xFCr diese Website.";
  el("site-name").value = s.name;
  el("site-pattern").value = s.pattern;
  el("site-priority").value = String(s.priority);
  el("site-enabled").checked = s.enabled;
  const buttons = el("button-list");
  buttons.replaceChildren(...s.buttons.map((b2, i) => option(String(i), `${b2.slot} \xB7 ${b2.label}`)));
  buttons.value = String(buttonIndex);
  el("button-editor").hidden = !button();
  const b = button();
  if (!b) return;
  const slots = el("slot");
  slots.replaceChildren(...Array.from({ length: 32 }, (_, i) => option(String(i + 1), String(i + 1))));
  slots.value = String(b.slot);
  el("button-label").value = b.label;
  drawSteps(b);
}
var types = [["click", "Element klicken"], ["fill", "Feld ausf\xFCllen"], ["text", "Text einf\xFCgen"], ["hotkey", "Seiten-Tastenk\xFCrzel"], ["scroll", "Scrollen"], ["open", "Seite \xF6ffnen"]];
function drawSteps(b) {
  el("steps").replaceChildren();
  b.steps.forEach((step, index) => {
    const card = document.createElement("div");
    card.className = "step";
    const row = document.createElement("div");
    row.className = "row";
    const title = document.createElement("strong");
    title.textContent = `Schritt ${index + 1}`;
    const remove = document.createElement("button");
    remove.type = "button";
    remove.textContent = "Schritt entfernen";
    remove.onclick = () => {
      collect();
      b.steps.splice(index, 1);
      draw();
    };
    row.append(title, remove);
    const grid = document.createElement("div");
    grid.className = "step-grid";
    const typeLabel = document.createElement("label");
    typeLabel.textContent = "Aktion";
    const type = document.createElement("select");
    type.dataset.field = "type";
    type.append(...types.map(([id, label]) => option(id, label)));
    type.value = step.type;
    typeLabel.append(type);
    const targetLabel = document.createElement("label");
    targetLabel.textContent = "Element (CSS-Selektor)";
    const target = document.createElement("input");
    target.dataset.field = "target";
    target.value = step.target;
    target.placeholder = step.type === "text" ? "Leer = fokussiertes Feld" : "#speichern";
    targetLabel.append(target);
    targetLabel.hidden = ["open", "scroll"].includes(step.type);
    const valueLabel = document.createElement("label");
    valueLabel.textContent = step.type === "open" ? "Zieladresse" : step.type === "hotkey" ? "Tastenk\xFCrzel" : step.type === "scroll" ? "Pixel (nach oben: negativ)" : "Text";
    const value = document.createElement("textarea");
    value.dataset.field = "value";
    value.value = step.value;
    value.rows = 2;
    value.placeholder = step.type === "hotkey" ? "Control+Shift+k" : step.type === "open" ? "https://example.org/" : step.type === "scroll" ? "600" : "";
    valueLabel.append(value);
    valueLabel.hidden = step.type === "click";
    type.onchange = () => {
      collect();
      draw();
    };
    grid.append(typeLabel, targetLabel);
    card.append(row, grid, valueLabel);
    el("steps").append(card);
  });
}
function collect() {
  const s = site();
  if (!s) return;
  s.name = el("site-name").value;
  s.pattern = el("site-pattern").value.trim();
  s.priority = Number(el("site-priority").value);
  s.enabled = el("site-enabled").checked;
  const b = button();
  if (!b) return;
  b.slot = Number(el("slot").value);
  b.label = el("button-label").value;
  b.steps = [...el("steps").querySelectorAll(".step")].map((card) => ({ type: card.querySelector("[data-field=type]").value, target: card.querySelector("[data-field=target]").value, value: card.querySelector("[data-field=value]").value }));
}
function action(id, run) {
  el(id).onclick = () => {
    void Promise.resolve().then(run).catch((e) => feedback(e.message));
  };
}
el("site-list").onchange = () => {
  const next = Number(el("site-list").value);
  collect();
  siteIndex = next;
  buttonIndex = 0;
  draw();
};
el("button-list").onchange = () => {
  const next = Number(el("button-list").value);
  collect();
  buttonIndex = next;
  draw();
};
action("add-site", () => {
  collect();
  if (config.websites.length >= 100) throw new Error("Maximal 100 Webseiten.");
  config.websites.push({ id: crypto.randomUUID(), name: "Neue Webseite", pattern: "example.org", priority: 0, enabled: true, buttons: [] });
  siteIndex = config.websites.length - 1;
  buttonIndex = 0;
  draw();
});
action("remove-site", () => {
  config.websites.splice(siteIndex, 1);
  siteIndex = Math.max(0, siteIndex - 1);
  buttonIndex = 0;
  draw();
});
action("add-button", () => {
  collect();
  const s = site();
  if (!s) return;
  const free = Array.from({ length: 32 }, (_, i) => i + 1).find((slot) => !s.buttons.some((b) => b.slot === slot));
  if (!free) throw new Error("Alle 32 Tastennummern sind belegt.");
  s.buttons.push({ slot: free, label: "Neue Aktion", steps: [{ type: "click", target: "", value: "" }] });
  buttonIndex = s.buttons.length - 1;
  draw();
});
action("remove-button", () => {
  collect();
  site()?.buttons.splice(buttonIndex, 1);
  buttonIndex = Math.max(0, buttonIndex - 1);
  draw();
});
action("add-step", () => {
  collect();
  const b = button();
  if (!b) return;
  if (b.steps.length >= 10) throw new Error("Maximal 10 Schritte je Taste.");
  b.steps.push({ type: "click", target: "", value: "" });
  draw();
});
el("grant").onclick = () => {
  collect();
  const s = site();
  if (!s) return;
  try {
    const origins = originsFor(s.pattern);
    void chrome.permissions.request({ origins }).then((granted) => {
      el("permission").textContent = granted ? "Website freigegeben." : "Freigabe wurde nicht erteilt. Klicken und Texteingaben sind auf dieser Website nicht verf\xFCgbar.";
    }).catch((e) => feedback(e.message));
  } catch (e) {
    feedback(e.message);
  }
};
action("save", async () => {
  collect();
  config = validateWorkspaces(config);
  await message({ type: "workspaces:save", config });
  draw();
  feedback("Webseiten und Tasten gespeichert. Zum Testen die gew\xFCnschte Webseite in den Vordergrund bringen.");
});
action("refresh", async () => {
  await message({ type: "refresh" });
  await updateStatus();
});
action("pair", async () => {
  await message({ type: "pair", code: el("pair-code").value.trim() });
  el("pair-code").value = "";
  feedback("Kopplung erfolgreich.");
});
action("resume", async () => {
  await message({ type: "resume-plugin" });
  feedback("Pause am Deck aufgehoben.");
});
action("pause", async () => {
  const saved = await chrome.storage.local.get("config");
  const old = validateConfig(saved.config ?? DEFAULT_CONFIG);
  await message({ type: "save", config: { ...old, paused: !old.paused } });
  feedback(!old.paused ? "PageDeck pausiert." : "PageDeck fortgesetzt.");
});
action("export", () => {
  collect();
  const clean = validateWorkspaces(config), url = URL.createObjectURL(new Blob([JSON.stringify(clean, null, 2)], { type: "application/json" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = "pagedeck-webseiten.json";
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1e3);
});
el("import").onchange = () => {
  void (async () => {
    const file = el("import").files?.[0];
    if (!file) return;
    if (file.size > 1e6) throw new Error("Datei ist zu gro\xDF.");
    config = validateWorkspaces(JSON.parse(await file.text()));
    siteIndex = buttonIndex = 0;
    draw();
    feedback("Webseiten geladen. Pr\xFCfen und speichern.");
  })().catch((e) => feedback(e.message));
};
async function updateStatus() {
  const result = await message({ type: "workspaces:get" });
  el("web-status").textContent = result.status?.message ?? "Noch nicht verbunden. Mit Stream Deck koppeln oder Verbindung pr\xFCfen.";
}
chrome.storage.onChanged.addListener((_c, area) => {
  if (area === "session") void updateStatus().catch(() => {
  });
});
var initial = await message({ type: "workspaces:get" });
config = validateWorkspaces(initial.config);
draw();
await message({ type: "refresh" });
await updateStatus();
