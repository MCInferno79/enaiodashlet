// src/shared/config.ts
var keyRE = /^[a-zA-Z0-9_-]{1,64}$/;
var isKey = (s) => typeof s === "string" && keyRE.test(s);
function plain(v) {
  return !!v && typeof v === "object" && !Array.isArray(v);
}
function short(v, n) {
  return typeof v === "string" && v.length <= n && !/[\u0000-\u001f]/.test(v);
}
function parsePattern(pattern) {
  if (!short(pattern, 1024) || !pattern.trim() || pattern !== pattern.trim()) throw new Error("Ung\xFCltiges Domain-/Pfadmuster.");
  const bare = pattern.replace(/^https?:\/\//i, "");
  if (/[?#@\\\s:]/.test(bare)) throw new Error("Muster nur als Hostname und optional /Pfad angeben; keine Parameter, Ports oder Zugangsdaten.");
  const [rawHost = "", ...rest] = bare.split("/");
  const wildcard = rawHost.startsWith("*.");
  const ascii = new URL("https://" + (wildcard ? rawHost.slice(2) : rawHost)).hostname.toLowerCase().replace(/\.$/, "");
  if (ascii.length > 253 || !ascii.split(".").every((x) => /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(x))) throw new Error("Ung\xFCltiger Hostname.");
  const path = rest.length ? "/" + rest.join("/") : "";
  if (path.includes("*") || /%(?:2f|5c)/i.test(path) || path.split("/").some((x) => x === "." || x === "..")) throw new Error("Pfad ohne Wildcards oder Punktsegmente angeben.");
  return { host: ascii, wildcard, path: path === "/" ? "" : path.replace(/\/$/, "") };
}
function validateConfig(v) {
  if (!plain(v) || Object.keys(v).some((k) => !["version", "paused", "unknown", "defaultProfile", "deviceIds", "rules"].includes(k))) throw new Error("Ung\xFCltige Konfiguration.");
  if (v.version !== 1 || typeof v.paused !== "boolean" || !["release", "keep", "default"].includes(String(v.unknown)) || !short(v.defaultProfile, 64) || v.defaultProfile && !isKey(v.defaultProfile)) throw new Error("Ung\xFCltige Grundeinstellungen.");
  if (v.unknown === "default" && !v.defaultProfile) throw new Error("Standardprofil ausw\xE4hlen.");
  if (!Array.isArray(v.deviceIds) || v.deviceIds.length > 32 || !v.deviceIds.every((x) => short(x, 128) && x.length > 0)) throw new Error("Ung\xFCltige Ger\xE4teauswahl.");
  if (!Array.isArray(v.rules) || v.rules.length > 200) throw new Error("H\xF6chstens 200 Regeln zul\xE4ssig.");
  const ids = /* @__PURE__ */ new Set();
  const rules = v.rules.map((r) => {
    if (!plain(r) || Object.keys(r).some((k) => !["id", "name", "pattern", "profile", "priority", "enabled"].includes(k)) || !isKey(r.id) || ids.has(r.id) || !short(r.name, 100) || !r.name || !short(r.pattern, 1024) || !isKey(r.profile) || !Number.isInteger(r.priority) || Math.abs(Number(r.priority)) > 1e4 || typeof r.enabled !== "boolean") throw new Error("Ung\xFCltige oder doppelte Regel.");
    ids.add(r.id);
    parsePattern(r.pattern);
    return { id: r.id, name: r.name, pattern: r.pattern, profile: r.profile, priority: r.priority, enabled: r.enabled };
  });
  return { version: 1, paused: v.paused, unknown: v.unknown, defaultProfile: v.defaultProfile, deviceIds: [...v.deviceIds], rules };
}
function matchRule(rawUrl, rules) {
  let url;
  try {
    url = new URL(rawUrl);
  } catch {
    return { host: "" };
  }
  if (!["http:", "https:"].includes(url.protocol)) return { host: "" };
  const host = url.hostname.toLowerCase().replace(/\.$/, "");
  const matched = rules.filter((r) => {
    if (!r.enabled) return false;
    const p = parsePattern(r.pattern);
    const hostOK = p.wildcard ? host.endsWith("." + p.host) && host !== p.host : host === p.host;
    return hostOK && (!p.path || url.pathname === p.path || url.pathname.startsWith(p.path + "/"));
  });
  matched.sort((a, b) => b.priority - a.priority);
  return { host, rule: matched[0] };
}
var DEFAULT_CONFIG = {
  version: 1,
  paused: false,
  unknown: "release",
  defaultProfile: "",
  deviceIds: [],
  rules: [
    { id: "bbb", name: "BigBlueButton", pattern: "bbb.herten.de", profile: "BBB", priority: 100, enabled: true },
    { id: "heki", name: "HeKI", pattern: "heki.herten.de", profile: "HeKI", priority: 100, enabled: true },
    { id: "grafana", name: "HeKI / Grafana", pattern: "hekiport.vw.intern.herten.de", profile: "Grafana", priority: 100, enabled: true },
    { id: "speakr", name: "Speakr", pattern: "speakr.vw.intern.herten.de", profile: "Speakr", priority: 100, enabled: true }
  ]
};

// src/extension/worker.ts
var BASE = "http://127.0.0.1:29381";
var pending = false;
var running = false;
var revision = 0;
async function api(route, data, token) {
  const response = await fetch(BASE + route, { method: "POST", headers: { "Content-Type": "application/json", ...token ? { Authorization: `Bearer ${token}` } : {} }, body: JSON.stringify(data), cache: "no-store", credentials: "omit", redirect: "error", signal: AbortSignal.timeout(2500) });
  const body = await response.json();
  if (!response.ok) throw new Error(response.status === 401 || response.status === 403 ? "Kopplung fehlt oder wurde erneuert. Bitte erneut koppeln." : response.status === 429 ? "Zu viele Kopplungsversuche. Eine Minute warten." : response.status === 409 ? "Verbindung wurde neu gestartet. Erneuter Versuch folgt." : "Lokaler Dienst: Anfrage abgelehnt.");
  return body;
}
async function settings() {
  const v = await chrome.storage.local.get(["config", "auth"]);
  const candidate = v.auth;
  return { config: validateConfig(v.config ?? DEFAULT_CONFIG), auth: candidate && /^[a-f0-9]{64}$/.test(candidate.token) ? candidate : void 0 };
}
async function saveStatus(s) {
  await chrome.storage.session.set({ status: { ...s, updatedAt: Date.now() } });
}
async function activeTab() {
  const windows = await chrome.windows.getAll({ windowTypes: ["normal", "popup"] });
  const window = windows.find((w) => w.focused);
  if (!window || window.id === void 0) return { focused: false, url: "" };
  const [tab] = await chrome.tabs.query({ active: true, windowId: window.id });
  return { focused: !!tab, url: tab?.url ?? "" };
}
async function evaluate() {
  const mine = revision;
  const { config, auth } = await settings();
  const active = await activeTab();
  const match = matchRule(active.url, config.rules);
  if (!auth?.token) {
    await saveStatus({ connected: false, host: match.host, message: "Bitte zuerst mit dem Stream-Deck-Plugin koppeln." });
    return;
  }
  try {
    const server = await api("/v1/status", {}, auth.token);
    if (mine !== revision) {
      pending = true;
      return;
    }
    const n = await chrome.storage.local.get("sequence");
    const sequence = typeof n.sequence === "number" && Number.isSafeInteger(n.sequence) ? n.sequence + 1 : 1;
    await chrome.storage.local.set({ sequence });
    const latest = await activeTab();
    if (mine !== revision || latest.focused !== active.focused || latest.url !== active.url) {
      pending = true;
      return;
    }
    const target = match.rule?.profile ?? (config.unknown === "default" ? config.defaultProfile : null);
    const result = await api("/v1/event", { instance: server.instance, sequence, focused: active.focused, target, keep: !match.rule && config.unknown === "keep", paused: config.paused, deviceIds: config.deviceIds }, auth.token);
    const missing = result.results.some((r) => r.state === "profile-missing");
    const failed = result.results.some((r) => r.state === "sdk-error");
    const paused = config.paused || result.paused;
    const selected = result.devices.filter((d) => d.isConnected && (!config.deviceIds.length || config.deviceIds.includes(d.id)));
    const requested = result.results.some((r) => r.state === "command-sent");
    let message = paused ? "Automatik pausiert \u2013 Profilfreigabe angefordert." : !active.focused ? "Edge im Hintergrund \u2013 Profilfreigabe angefordert." : selected.length === 0 ? "Kein ausgew\xE4hltes Stream Deck verbunden." : failed ? "Stream-Deck-Befehl fehlgeschlagen." : missing ? "Profil f\xFCr dieses Ger\xE4t fehlt. Exportdatei \xFCber den CMD-Assistenten einbinden." : requested ? `Microsoft Edge erkannt \u2013 ${match.host || "interne Seite"} \u2013 Profilbefehl ${target ?? "beibehalten"} gesendet.` : "Keine passende Regel \u2013 Profilfreigabe angefordert.";
    await saveStatus({ connected: true, host: match.host, profile: target, message, server: result });
    await chrome.action.setBadgeText({ text: paused ? "\u2161" : missing || failed ? "!" : "" });
    await chrome.action.setBadgeBackgroundColor({ color: missing || failed ? "#b45309" : "#0f766e" });
  } catch (e) {
    await saveStatus({ connected: false, host: match.host, message: e instanceof TypeError || e instanceof Error && e.name === "TimeoutError" ? "Lokaler Dienst nicht erreichbar. Stream Deck starten; erneuter Versuch beim n\xE4chsten Browserereignis oder innerhalb von etwa 30 Sekunden." : e instanceof Error ? e.message : "Verbindungsfehler." });
    await chrome.action.setBadgeText({ text: "!" });
  }
}
async function drain() {
  if (running) return;
  running = true;
  try {
    while (pending) {
      pending = false;
      await evaluate();
    }
  } catch {
    await saveStatus({ connected: false, message: "Einstellungen oder Browserzustand konnten nicht gelesen werden." });
  } finally {
    running = false;
  }
}
function schedule() {
  ++revision;
  pending = true;
  void drain();
}
chrome.tabs.onActivated.addListener(schedule);
chrome.tabs.onUpdated.addListener((_id, change, tab) => {
  if (tab.active && (change.url !== void 0 || change.status === "complete")) schedule();
});
chrome.tabs.onCreated.addListener(schedule);
chrome.tabs.onRemoved.addListener(schedule);
chrome.tabs.onReplaced.addListener(schedule);
chrome.tabs.onAttached.addListener(schedule);
chrome.tabs.onDetached.addListener(schedule);
chrome.windows.onFocusChanged.addListener(schedule);
chrome.windows.onRemoved.addListener(schedule);
chrome.webNavigation.onHistoryStateUpdated.addListener((e) => {
  if (e.frameId === 0) schedule();
});
chrome.webNavigation.onReferenceFragmentUpdated.addListener((e) => {
  if (e.frameId === 0) schedule();
});
chrome.runtime.onStartup.addListener(schedule);
chrome.runtime.onInstalled.addListener(() => {
  void chrome.storage.local.get("config").then((v) => {
    if (!v.config) return chrome.storage.local.set({ config: DEFAULT_CONFIG });
  }).then(schedule);
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && (changes.config || changes.auth)) schedule();
});
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === "heki-reconnect") schedule();
});
chrome.action.onClicked.addListener(() => {
  void chrome.runtime.openOptionsPage();
});
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (sender.id !== chrome.runtime.id || sender.url !== chrome.runtime.getURL("options.html")) return;
  const run = async () => {
    switch (message?.type) {
      case "status": {
        const v = await chrome.storage.session.get("status");
        return { ok: true, status: v.status };
      }
      case "refresh":
        schedule();
        return { ok: true };
      case "save": {
        const config = validateConfig(message.config);
        await chrome.storage.local.set({ config });
        schedule();
        return { ok: true };
      }
      case "pair": {
        if (typeof message.code !== "string" || !/^[a-f0-9]{48}$/.test(message.code)) throw new Error("Kopplungscode ung\xFCltig oder unvollst\xE4ndig.");
        const auth = await api("/v1/pair", { code: message.code });
        await chrome.storage.local.set({ auth: { token: auth.token } });
        schedule();
        return { ok: true };
      }
      case "resume-plugin": {
        const { auth } = await settings();
        if (!auth) throw new Error("Bitte koppeln.");
        await api("/v1/pause", { paused: false }, auth.token);
        schedule();
        return { ok: true };
      }
      default:
        throw new Error("Unbekannter Befehl.");
    }
  };
  void run().then(respond, (e) => respond({ ok: false, error: e instanceof Error ? e.message : "Fehler" }));
  return true;
});
void chrome.alarms.create("heki-reconnect", { periodInMinutes: 0.5 });
schedule();
